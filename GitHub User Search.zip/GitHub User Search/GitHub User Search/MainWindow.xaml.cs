﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace GitHub_User_Search
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static HttpClient client = new HttpClient();

        public static ObservableCollection<GitHubUser> gitHubUsers = new ObservableCollection<GitHubUser>();
        public static ObservableCollection<string> logins = new ObservableCollection<string>();

        public MainWindow()
        {
            InitializeComponent();
            gitUserDataGrid.ItemsSource = gitHubUsers;
            Suggestiontxt.Text = string.Join(" ", logins);
        }

        private async void Searchbtn_Click_1(object sender, RoutedEventArgs e)
        {
            // Code for when the search button is clicked
            client = new HttpClient();
            try
            {
                logins.Clear();
                await RunSearchAsync(Searchtxt.Text);
            }
            catch
            {
                return;
            }
        }

        private async void Searchtxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            // code for when the user is typing
            client = new HttpClient();
            try
            {
                logins.Clear();
                var suggestionString = await RunSuggestionAsync(Searchtxt.Text);
                Suggestiontxt.Text = suggestionString;
            }
            catch
            {
                return;
            }
        }

        static async Task<string> RunSuggestionAsync(string searchText)
        {
            client.BaseAddress = new Uri("https://api.github.com/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("GitHubUserSearch", "1"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                await GetGitHubUsers($"search/users?q={searchText}"); // no limit on searches, just user queries
            }
            catch
            {
                return string.Join(" ", logins);
            }
            return string.Join(" ", logins);
        }

        static async Task RunSearchAsync(string searchText)
        {
            // set up the HTTP client for API calls, then search for user logins, then search for specific users and get the info for the screen
            client.BaseAddress = new Uri("https://api.github.com/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("GitHubUserSearch", "2"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                await GetGitHubUsers($"search/users?q={searchText}&per_page=12"); // have to limit to 5 results because of rate limit
            }
            catch
            {
                return;
            }

            try
            {
                gitHubUsers.Clear();
                foreach (var login in logins)
                {
                    GitHubUser user = await GetUsersByLogin($"users/{login}");
                    gitHubUsers.Add(user);
                }               

            }
            catch
            {
                return;
            }
        }
        static async Task GetGitHubUsers(string searchPath)
        {
            // search for specific users after getting user logins
            string gitItems = "";
            HttpResponseMessage searchResponse = await client.GetAsync(searchPath);
            if (searchResponse.IsSuccessStatusCode)
            {
                gitItems = await searchResponse.Content.ReadAsStringAsync();
            }
            dynamic jsonItems = JsonConvert.DeserializeObject(gitItems);

            
            foreach (var item in jsonItems["items"])
            {
                string login = item["login"].ToString();
                logins.Add(login);
            }
            return;
        }
        static async Task<GitHubUser> GetUsersByLogin(string userPath)
        {
            string gituser = "";
            HttpResponseMessage userResponse = await client.GetAsync(userPath);
            if (userResponse.IsSuccessStatusCode)
            {
                gituser = await userResponse.Content.ReadAsStringAsync();
            }
            dynamic jsonUser = JsonConvert.DeserializeObject(gituser);
            GitHubUser user = new GitHubUser();
            user.username = jsonUser["login"].ToString();
            user.avatar = jsonUser["avatar_url"].ToString();
            //string avatarUrl = jsonUser["avatar_url"].ToString();
            //add some logic to get the avatar image from the URL
            user.location = jsonUser["location"].ToString();
            user.realName = jsonUser["name"].ToString();
            user.email = jsonUser["email"].ToString();
            user.countOfRepositories = jsonUser["public_repos"] ?? 0;
            user.accountCreation = jsonUser["created_at"] ?? "12/30/1899";
            user.lastUpdate = jsonUser["updated_at"] ?? "12/30/1899";

            return user;
        }
    }

    public class GitHubUser
    {
        public string username { get; set; }
        public string  avatar { get; set; } // change to an image when I can get an image
        public string location { get; set; }
        public string realName { get; set; }
        public string email { get; set; }
        public int countOfRepositories { get; set; }
        public DateTime accountCreation { get; set; }
        public DateTime lastUpdate { get; set; }
    }
}
